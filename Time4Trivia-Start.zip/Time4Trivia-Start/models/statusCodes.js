exports.STATUS_CODES = {
    success: 'Success',
    failure: 'Failure'
};