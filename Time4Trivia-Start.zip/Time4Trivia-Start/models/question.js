class Question{
    constructor(questionId, question, answers){
        this.questionId = questionId;
        this.question = question;
        this.answers = answers;
    }
}

exports.Question = Question;